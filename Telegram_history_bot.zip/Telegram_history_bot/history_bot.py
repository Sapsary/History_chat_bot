import logging
import psycopg2
from datetime import datetime
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, filters, ContextTypes
from datasets import load_dataset
from openai import OpenAI
import re
import os

TELEGRAM_TOKEN = "8729147416:AAGywxCSzqbU45aMpnf3mmbFqCLN-JiqgXI"
QWEN_DATA = "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"
HF_TOKEN = "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"

# PostgreSQL подключение
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "history_bot",
    "user": "postgres",
    "password": "1234"
}

# Логирование
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Добавьте этот обработчик ошибок
async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.error(f"Exception: {context.error}")
    if update and update.effective_message:
        await update.effective_message.reply_text("⚠️ Произошла ошибка. Администратор уже уведомлён.")

# ================= ПОДКЛЮЧЕНИЕ К POSTGRESQL =================
def get_db_connection():
    """Создаёт соединение с PostgreSQL"""
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        return conn
    except Exception as e:
        logger.error(f"Ошибка подключения к БД: {e}")
        return None

def init_db():
    """Инициализация таблицы (если не существует)"""
    conn = get_db_connection()
    if conn:
        try:
            cur = conn.cursor()
            cur.execute("""
                CREATE TABLE IF NOT EXISTS logs (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT NOT NULL,
                    username VARCHAR(255),
                    language VARCHAR(2),
                    question TEXT,
                    answer TEXT,
                    rating INTEGER,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()
            logger.info("✅ Таблица logs успешно создана/проверена")
        except Exception as e:
            logger.error(f"Ошибка создания таблицы: {e}")
        finally:
            cur.close()
            conn.close()

openai_client = OpenAI(api_key=QWEN_DATA)

# ================= ЗАГРУЗКА ДАТАСЕТА (опционально) =================
print("Загрузка датасета истории...")
history_knowledge = []
try:
    # Пробуем загрузить датасет
    dataset = load_dataset("nielsprovos/world-history-1500-qa", token=HF_TOKEN, split="train", streaming=True)
    count = 0
    for item in dataset:
        if count >= 500:
            break
        history_knowledge.append({
            "question": item.get("question", "").lower(),
            "answer": item.get("answer", "")
        })
        count += 1
    print(f"✅ Загружено")
except Exception as e:
    print(f"⚠️ Ошибка загрузки датасета: {e}")
    history_knowledge = []

# ================= ЯЗЫКИ =================
user_language = {}  # user_id -> 'ru', 'kk', 'en'

texts = {
    'ru': {
        'start': "🌍 Привет! Я исторический помощник.\n\nЗадавайте любые вопросы по всемирной истории!",
        'help': "📚 Как я могу помочь:\n\n• Задайте вопрос по истории\n• Используйте меню для навигации\n• Оцените ответы звёздочками\n\nПримеры вопросов:\n- Кто такой Александр Македонский?\n- Когда началась Вторая мировая война?\n- Какое влияние Чингисхана на мировую историю?",
        'not_history': "❌ Извините, я могу отвечать только на вопросы по всемирной истории.\n\nПопробуйте спросить что-то об исторических событиях, личностях или эпохах.",
        'error': "⚠️ Извините, произошла ошибка. Пожалуйста, попробуйте позже.",
        'rate_prompt': "⭐ Оцените ответ от 1 до 5:",
        'thanks': "🙏 Спасибо за вашу оценку!",
        'menu': "📋 Главное меню:",
        'fact_prompt': "📖 Интересный исторический факт:",
        'change_lang': "🌐 Выберите язык / Тілді таңдаңыз / Choose language:",
        'stats': "📊 Статистика за всё время:\n\n• Всего запросов: {total}\n• В рамках истории: {history}\n• Средняя оценка: {avg_rating:.1f}/5\n• Активных пользователей: {users}"
    },
    'kk': {
        'start': "🌍 Сәлем! Мен тарихи көмекшімін.\n\nӘлемдік тарих бойынша кез келген сұрақ қойыңыз!",
        'help': "📚 Мен қалай көмектесе аламын:\n\n• Тарих сұрағын жазыңыз\n• Мәзірді пайдаланыңыз\n• Жауаптарды жұлдызшамен бағалаңыз\n\nСұрақ үлгілері:\n- Александр Македонский кім?\n- Екінші дүниежүзілік соғыс қашан басталды?\n- Шыңғыс ханның әлемдік тарихқа әсері қандай?",
        'not_history': "❌ Кешіріңіз, мен тек әлемдік тарих бойынша сұрақтарға жауап бере аламын.\n\nТарихи оқиғалар, тұлғалар немесе дәуірлер туралы сұраңыз.",
        'error': "⚠️ Кешіріңіз, қате орын алды. Кейінірек қайталап көріңіз.",
        'rate_prompt': "⭐ Жауапты 1-ден 5-ке дейін бағалаңыз:",
        'thanks': "🙏 Бағаңыз үшін рахмет!",
        'menu': "📋 Бас мәзір:",
        'fact_prompt': "📖 Қызықты тарихи факт:",
        'change_lang': "🌐 Тілді таңдаңыз / Выберите язык / Choose language:",
        'stats': "📊 Барлық уақыттағы статистика:\n\n• Сұрақтар саны: {total}\n• Тарих бойынша: {history}\n• Орташа баға: {avg_rating:.1f}/5\n• Белсенді қолданушылар: {users}"
    },
    'en': {
        'start': "🌍 Hi! I'm a history assistant.\n\nAsk me anything about world history!",
        'help': "📚 How I can help:\n\n• Ask a history question\n• Use the menu for navigation\n• Rate answers with stars\n\nExample questions:\n- Who was Alexander the Great?\n- When did WWII start?\n- What was Genghis Khan's influence on world history?",
        'not_history': "❌ Sorry, I can only answer world history questions.\n\nTry asking about historical events, figures, or eras.",
        'error': "⚠️ Sorry, an error occurred. Please try again later.",
        'rate_prompt': "⭐ Rate the answer from 1 to 5:",
        'thanks': "🙏 Thanks for your rating!",
        'menu': "📋 Main menu:",
        'fact_prompt': "📖 Interesting historical fact:",
        'change_lang': "🌐 Choose language / Выберите язык / Тілді таңдаңыз:",
        'stats': "📊 Statistics for all time:\n\n• Total requests: {total}\n• History-related: {history}\n• Average rating: {avg_rating:.1f}/5\n• Active users: {users}"
    }
}

# ================= ОПРЕДЕЛЕНИЕ ЯЗЫКА =================
def detect_language(text):
    text_low = text.lower()
    kazakh_chars = ['ә', 'ғ', 'қ', 'ң', 'ө', 'ұ', 'ү', 'һ', 'і']
    if any(char in text_low for char in kazakh_chars):
        return 'kk'
    if re.search(r'[а-яё]', text_low):
        return 'ru'
    return 'en'

# ================= ПРОВЕРКА ТЕМАТИКИ (история) - РАСШИРЕННАЯ =================
def is_history_question(question, lang):
    text_low = question.lower()
    
    # Список исторических личностей (всегда проверяем независимо от языка)
    historical_figures = [
        'чингисхан', 'чингис', 'генгис хан', 'темучин', 'chinggis khan', 'genghis khan',
        'александр македонский', 'юлий цезарь', 'наполеон', 'петр первый', 'екатерина великая',
        'сталин', 'гитлер', 'черчилль', 'ленин', 'маркс', 'колумб', 'магеллан',
        'клеопатра', 'тутанхамон', 'сократ', 'платон', 'аристотель', 'да винчи',
        'галилей', 'коперник', 'дарвин', 'моцарт', 'бетховен', 'шекспир',
        'суворов', 'кутузов', 'жуков', 'иван грозный', 'петр'
    ]
    
    # Проверяем на исторические личности
    for figure in historical_figures:
        if figure in text_low:
            return True
    
    # Исторические слова-маркеры
    history_markers = {
        'ru': ['войн', 'истори', 'битв', 'сражен', 'революц', 'импери', 'корол', 'цар', 'хан',
               'правител', 'древн', 'средневеков', 'цивилизац', 'тысячелет', 'год', 'век',
               'династи', 'завоева', 'поход', 'восстани', 'договор', 'союз', 'арми', 'флот',
               'крестов', 'ренессанс', 'просвещение', 'феодализм', 'капитализм'],
        'kk': ['соғыс', 'тарих', 'шайқас', 'төңкеріс', 'империя', 'патша', 'хан', 'билеуші',
               'ежелгі', 'ортағасыр', 'өркениет', 'жыл', 'ғасыр', 'әскер'],
        'en': ['war', 'history', 'battle', 'revolution', 'empire', 'king', 'queen', 'emperor',
               'ancient', 'medieval', 'civilization', 'year', 'century', 'dynasty', 'conquest']
    }
    
    markers = history_markers.get(lang, history_markers['en'])
    for marker in markers:
        if marker in text_low:
            return True
    
    # Вопросы-маркеры
    question_markers = {
        'ru': ['кто такой', 'кто такая', 'кем был', 'когда был', 'в каком году', 'какого числа',
               'где произошло', 'почему произошло', 'что такое', 'что означает', 'расскажи о',
               'что ты знаешь о', 'какую роль', 'какое влияние', 'каковы причины', 'какие последствия'],
        'kk': ['кім', 'қашан', 'қайда', 'неге', 'қалай', 'не білесің', 'қандай әсері'],
        'en': ['who was', 'who is', 'when was', 'when did', 'where was', 'why did', 'what is',
               'tell me about', 'what do you know about', 'in what year', 'what influence']
    }
    
    markers_q = question_markers.get(lang, question_markers['en'])
    for marker in markers_q:
        if marker in text_low:
            return True
    
    return False

# ================= ПОИСК В ДАТАСЕТЕ =================
def find_in_dataset(question):
    if not history_knowledge:
        return None
    question_low = question.lower()
    best_match = None
    best_score = 0
    for item in history_knowledge:
        q = item['question']
        if any(word in question_low for word in q.split()[:5]):
            score = len(set(q.split()) & set(question_low.split()))
            if score > best_score and score > 0:
                best_score = score
                best_match = item['answer']
        if q in question_low or question_low in q:
            if len(q) > best_score:
                best_score = len(q)
                best_match = item['answer']
    return best_match

async def ask_query(question, lang):
    system_prompts = {
        'ru': "Ты эксперт по всемирной истории. Отвечай кратко (2-4 предложения), точно, только по теме истории. Если не знаешь — скажи 'Я не знаю ответа на этот вопрос'. Отвечай на русском языке.",
        'kk': "Сіз әлемдік тарих бойынша сарапшысыз. Қысқа (2-4 сөйлем) әрі нақты жауап беріңіз. Тек тарих бойынша. Білмесеңіз, 'Мен бұл сұраққа жауапты білмеймін' деп айтыңыз. Қазақ тілінде жауап беріңіз.",
        'en': "You are a world history expert. Answer briefly (2-4 sentences), accurately, only on history. If unknown, say 'I don't know the answer to this question'. Answer in English."
    }
    try:
        response = openai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_prompts.get(lang, system_prompts['en'])},
                {"role": "user", "content": question}
            ],
            max_tokens=300,
            temperature=0.7
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        logger.error(f"model error: {e}")
        return None

# ================= ЛОГИРОВАНИЕ В POSTGRESQL =================
def log_interaction(user_id, username, lang, question, answer, rating=None):
    conn = get_db_connection()
    if not conn:
        logger.error("Не удалось подключиться к БД для логирования")
        return
    
    try:
        cur = conn.cursor()
        cur.execute("""
            INSERT INTO logs (user_id, username, language, question, answer, rating, timestamp)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (user_id, username, lang, question, answer[:1000] if answer else None, rating, datetime.now()))
        conn.commit()
        logger.info(f"Лог сохранён в PostgreSQL: user={username}, question={question[:50]}")
    except Exception as e:
        logger.error(f"Ошибка логирования: {e}")
    finally:
        cur.close()
        conn.close()

def get_statistics():
    """Получение статистики из БД"""
    conn = get_db_connection()
    if not conn:
        return None
    
    try:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM logs")
        total = cur.fetchone()[0]
        
        cur.execute("SELECT COUNT(*) FROM logs WHERE answer != 'OUT_OF_SCOPE'")
        history = cur.fetchone()[0]
        
        cur.execute("SELECT AVG(rating) FROM logs WHERE rating IS NOT NULL")
        avg_rating = cur.fetchone()[0] or 0
        
        cur.execute("SELECT COUNT(DISTINCT user_id) FROM logs")
        users = cur.fetchone()[0]
        
        return {
            'total': total,
            'history': history,
            'avg_rating': avg_rating,
            'users': users
        }
    except Exception as e:
        logger.error(f"Ошибка получения статистики: {e}")
        return None
    finally:
        cur.close()
        conn.close()

# ================= КОМАНДЫ =================
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    text = update.message.text
    if '/start' in text:
        lang = 'ru'
    else:
        lang = detect_language(text)
    user_language[user_id] = lang
    await update.message.reply_text(texts[lang]['start'])
    await show_main_menu(update, context)

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    lang = user_language.get(user_id, 'ru')
    keyboard = [
        [InlineKeyboardButton("❓ Помощь / Help / Көмек", callback_data='help')],
        [InlineKeyboardButton("🌍 Случайный факт / Random fact", callback_data='random_fact')],
        [InlineKeyboardButton("📊 Статистика / Statistics", callback_data='stats')],
        [InlineKeyboardButton("🗣 Сменить язык / Change language", callback_data='change_lang')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(texts[lang]['menu'], reply_markup=reply_markup)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    lang = user_language.get(user_id, 'ru')
    await update.message.reply_text(texts[lang]['help'])

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    username = update.effective_user.username or "unknown"
    question = update.message.text.strip()
    lang = user_language.get(user_id, detect_language(question))
    
    user_language[user_id] = lang
    
    if not question:
        return
    
    if not is_history_question(question, lang):
        await update.message.reply_text(texts[lang]['not_history'])
        log_interaction(user_id, username, lang, question, "OUT_OF_SCOPE", None)
        return
    
    await update.message.chat.send_action(action="typing")
    
    # Сначала поиск в датасете
    answer = find_in_dataset(question)
    if answer:
        logger.info(f"Ответ из датасета для: {question}")
    else:
        answer = await ask_query(question, lang)
    
    if not answer:
        answer = texts[lang]['error']
    
    await update.message.reply_text(answer)
    
    context.user_data['last_answer'] = answer
    context.user_data['last_question'] = question
    
    keyboard = [[InlineKeyboardButton(f"{i} ⭐", callback_data=f'rate_{i}') for i in range(1, 6)]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(texts[lang]['rate_prompt'], reply_markup=reply_markup)
    
    log_interaction(user_id, username, lang, question, answer, None)

async def random_fact(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Отправляет случайный исторический факт"""
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    lang = user_language.get(user_id, 'ru')
    
    await query.message.chat.send_action(action="typing")
    
    # Промпты на разных языках
    fact_prompts = {
        'ru': "Расскажи один интересный и малоизвестный факт из всемирной истории. Ответ должен быть кратким (2-3 предложения).",
        'kk': "Әлемдік тарихтан бір қызықты және аз белгілі факт айт. Жауап қысқа болуы керек (2-3 сөйлем).",
        'en': "Tell one interesting and little-known fact from world history. The answer should be brief (2-3 sentences)."
    }
    
    prompt = fact_prompts.get(lang, fact_prompts['en'])
    fact = await ask_query(prompt, lang)
    
    if not fact:
        fact = texts[lang]['error']
    
    # Заголовки на разных языках
    fact_titles = {
        'ru': "📖 Интересный исторический факт:",
        'kk': "📖 Қызықты тарихи факт:",
        'en': "📖 Interesting historical fact:"
    }
    
    title = fact_titles.get(lang, fact_titles['en'])
    
    await query.edit_message_text(f"{title}\n\n{fact}")

async def show_statistics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    lang = user_language.get(user_id, 'ru')
    
    stats = get_statistics()
    if stats:
        message = texts[lang]['stats'].format(
            total=stats['total'],
            history=stats['history'],
            avg_rating=stats['avg_rating'],
            users=stats['users']
        )
    else:
        message = "⚠️ Не удалось получить статистику / Статистиканы алу мүмкін болмады / Failed to get statistics"
    
    await query.edit_message_text(message)

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    lang = user_language.get(user_id, 'ru')
    data = query.data
    
    if data.startswith('rate_'):
        rating = int(data.split('_')[1])
        conn = get_db_connection()
        if conn:
            try:
                cur = conn.cursor()
                cur.execute("""
                    UPDATE logs 
                    SET rating = %s 
                    WHERE id = (SELECT MAX(id) FROM logs WHERE user_id = %s)
                """, (rating, user_id))
                conn.commit()
                await query.edit_message_text(texts[lang]['thanks'])
            except Exception as e:
                logger.error(f"Rating update error: {e}")
                await query.edit_message_text(texts[lang]['thanks'])
            finally:
                cur.close()
                conn.close()
        else:
            await query.edit_message_text(texts[lang]['thanks'])
    
    elif data == 'help':
        await query.edit_message_text(texts[lang]['help'])
    
    elif data == 'random_fact':
        await random_fact(update, context)
    
    elif data == 'stats':
        await show_statistics(update, context)
    
    # 👇 ДОБАВЬТЕ ЭТУ СЕКЦИЮ 👇
    elif data == 'person_of_day':
        await query.message.chat.send_action(action="typing")
        person = await ask_query("Назови одну интересную историческую личность и напиши 2-3 предложения о её вкладе в историю", lang)
        if not person:
            person = texts[lang]['error']
        await query.edit_message_text(f"👑 **Историческая личность дня**\n\n{person}", parse_mode='Markdown')
    # 👆 КОНЕЦ ДОБАВЛЕННОЙ СЕКЦИИ 👆
    
    elif data == 'change_lang':
        keyboard = [
            [InlineKeyboardButton("🇷🇺 Русский", callback_data='lang_ru')],
            [InlineKeyboardButton("🇰🇿 Қазақша", callback_data='lang_kk')],
            [InlineKeyboardButton("🇬🇧 English", callback_data='lang_en')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.edit_message_text(texts[lang]['change_lang'], reply_markup=reply_markup)
    
    elif data.startswith('lang_'):
        new_lang = data.split('_')[1]
        user_language[user_id] = new_lang
        await query.edit_message_text(texts[new_lang]['start'])
        
        keyboard = [
            [InlineKeyboardButton("❓ Помощь / Help / Көмек", callback_data='help')],
            [InlineKeyboardButton("🌍 Случайный факт / Random fact", callback_data='random_fact')],
            [InlineKeyboardButton("👑 Личность дня", callback_data='person_of_day')],  # Добавьте эту кнопку
            [InlineKeyboardButton("📊 Статистика / Statistics", callback_data='stats')],
            [InlineKeyboardButton("🗣 Сменить язык / Change language", callback_data='change_lang')]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await query.message.reply_text(texts[new_lang]['menu'], reply_markup=reply_markup)
        

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Показывает главное меню с кнопками на нужном языке"""
    user_id = update.effective_user.id
    lang = user_language.get(user_id, 'ru')
    
    # Текст кнопок на разных языках
    button_texts = {
        'ru': {
            'help': '❓ Помощь',
            'fact': '🌍 Случайный факт',
            'stats': '📊 Статистика',
            'lang': '🗣 Сменить язык'
        },
        'kk': {
            'help': '❓ Көмек',
            'fact': '🌍 Кездейсоқ факт',
            'stats': '📊 Статистика',
            'lang': '🗣 Тілді өзгерту'
        },
        'en': {
            'help': '❓ Help',
            'fact': '🌍 Random fact',
            'stats': '📊 Statistics',
            'lang': '🗣 Change language'
        }
    }
    
    texts = button_texts.get(lang, button_texts['en'])
    
    keyboard = [
        [InlineKeyboardButton(texts['help'], callback_data='help')],
        [InlineKeyboardButton(texts['fact'], callback_data='random_fact')],
        [InlineKeyboardButton(texts['stats'], callback_data='stats')],
        [InlineKeyboardButton(texts['lang'], callback_data='change_lang')]
    ]
    
    # Добавляем кнопку "Историческая личность дня"
    keyboard.append([InlineKeyboardButton("👑 Историческая личность дня", callback_data='person_of_day')])
    
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    # Отправляем сообщение с меню
    if update.callback_query:
        await update.callback_query.edit_message_text(
            texts['menu_prompt'] if 'menu_prompt' in texts else "📋 Выберите действие:",
            reply_markup=reply_markup
        )
    else:
        await update.message.reply_text(
            "📋 Выберите действие:",
            reply_markup=reply_markup
        )

# ================= MAIN =================
# ================= КОМАНДЫ ДЛЯ ПОСТОЯННОГО МЕНЮ =================
async def stats_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /stats - показывает статистику"""
    user_id = update.effective_user.id
    lang = user_language.get(user_id, 'ru')
    
    stats = get_statistics()
    if stats:
        message = texts[lang]['stats'].format(
            total=stats['total'],
            history=stats['history'],
            avg_rating=stats['avg_rating'],
            users=stats['users']
        )
    else:
        message = "⚠️ Не удалось получить статистику / Статистиканы алу мүмкін болмады / Failed to get statistics"
    
    await update.message.reply_text(message)

async def language_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /language - смена языка"""
    user_id = update.effective_user.id
    
    keyboard = [
        [InlineKeyboardButton("🇷🇺 Русский", callback_data='lang_ru')],
        [InlineKeyboardButton("🇰🇿 Қазақша", callback_data='lang_kk')],
        [InlineKeyboardButton("🇬🇧 English", callback_data='lang_en')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "🌐 Выберите язык / Тілді таңдаңыз / Choose language:",
        reply_markup=reply_markup
    )

async def history_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Команда /history - случайный исторический факт"""
    user_id = update.effective_user.id
    lang = user_language.get(user_id, 'ru')
    
    await update.message.chat.send_action(action="typing")
    
    fact = await ask_query("Расскажи один интересный и малоизвестный факт из всемирной истории", lang)
    if not fact:
        fact = texts[lang]['error']
    
    await update.message.reply_text(f"📖 {fact}")

async def setup_commands(app):
    """Установка команд для постоянного меню"""
    commands = [
        BotCommand("start", "🚀 Запустить бота / Start the bot"),
        BotCommand("help", "❓ Помощь / Help"),
        BotCommand("stats", "📊 Статистика"),
        BotCommand("language", "🌐 Сменить язык"),
    ]
    await app.bot.set_my_commands(commands)

def main():
    print("🚀 Запуск исторического Telegram-бота...")
    
    # Инициализация БД
    init_db()
    
    app = Application.builder().token(TELEGRAM_TOKEN).build()
    
    # Регистрируем команды
    app.add_handler(CommandHandler("start", start))
    app.add_error_handler(error_handler)
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("stats", stats_command))
    app.add_handler(CommandHandler("language", language_command))
    app.add_handler(CommandHandler("history", history_command))
    
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.add_handler(CallbackQueryHandler(button_handler))
    
    # Устанавливаем постоянное меню
    app.post_init = setup_commands  # Это сработает после инициализации
    
    print("✅ Бот успешно запущен!")
    print("📊 Логи сохраняются в PostgreSQL (база: history_bot)")
    print("🤖 Найдите бота в Telegram и отправьте /start")
    
    app.run_polling()

if __name__ == "__main__":
    main()